
export default function Error(){
    return(
        <div>
            YOU ARE NOT AUTHORIZED TO THIS PAGE

        </div>
    );

}